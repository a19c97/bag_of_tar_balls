#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include "pagetable.h"


extern int memsize;

extern int debug;

extern struct frame *coremap;

int clock_hand;

/* Page to evict is chosen using the clock algorithm.
 * Returns the page frame number (which is also the index in the coremap)
 * for the page that is to be evicted.
 */

int clock_evict() {

	int found = 0;
	int page = -1;

	while (!found){

		if (clock_hand == memsize){
			clock_hand = 0; // wraps around
		}

		if (coremap[clock_hand].pte->frame & PG_REF){ // check if ref is on
				//turn off ref
				coremap[clock_hand].pte->frame &= ~PG_REF;
		} else {
				page = clock_hand;
				found = 1;
		}
		
		clock_hand += 1;
	}

	return page;
}

/* This function is called on each access to a page to update any information
 * needed by the clock algorithm.
 * Input: The page table entry for the page that is being accessed.
 */
void clock_ref(pgtbl_entry_t *p) {
	// turn on ref bit
	p->frame |= PG_REF;
	return;
}

/* Initialize any data structures needed for this replacement
 * algorithm.
 */
void clock_init() {
	// clock hand that goes around looking for page to evict
	clock_hand = 0;
}
