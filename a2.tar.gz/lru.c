#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include "pagetable.h"


extern int memsize;

extern int debug;

extern struct frame *coremap;

// A clock to be used for the timestamps of pages
static unsigned int clock;

/* Page to evict is chosen using the accurate LRU algorithm.
 * Returns the page frame number (which is also the index in the coremap)
 * for the page that is to be evicted.
 */

int lru_evict() {

	int page = -1;

	// smallest is the timestamp of the oldest page
	unsigned int smallest = clock;
	
	int i;
	for (i = 0; i < memsize; i++) {
		int time = coremap[i].pte->timestamp;
		// timestamps are initialized to 0 and clock starts from 1
		if ((time != 0) && (time < smallest)) {
			smallest = time;
			page = i;
		}
	}

	return page;
}

/* This function is called on each access to a page to update any information
 * needed by the lru algorithm.
 * Input: The page table entry for the page that is being accessed.
 */
void lru_ref(pgtbl_entry_t *p) {

	p->timestamp = clock;
	clock++;

	return;
}


/* Initialize any data structures needed for this
 * replacement algorithm
 */
void lru_init() {

	clock = 1;

	return;
}
