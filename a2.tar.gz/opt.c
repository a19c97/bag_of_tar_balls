#include <stdio.h>
#include <assert.h>
#include <unistd.h>
#include <getopt.h>
#include <stdlib.h>
#include "pagetable.h"

#define MAX_BUF_SIZE 256


extern int memsize;

extern int debug;

extern struct frame *coremap;

extern char *tracefile;

int num_of_traces;
addr_t *traces; // list of virtual addresses from tracefile
static int trace_pos; // to keep track of which instructions we have executed
int *distances; // a list of the distance of the next occurance

/* Page to evict is chosen using the optimal (aka MIN) algorithm. 
 * Returns the page frame number (which is also the index in the coremap)
 * for the page that is to be evicted.
 */
int opt_evict() {
	
	// Loop through all the vaddr
	int i;
	for (i = 0; i < memsize; i++) {
		
    	addr_t curr = coremap[i].vaddr;

    	int pos = trace_pos + 1;

    	// Want to find if page occurs again in the remaining trace
	    while ((traces[pos] != curr) && (pos <= num_of_traces)) {
	    	pos++;
	    }

	    if (pos <= num_of_traces) { 
	    	// Record the distance to the next occurance of page
			distances[i] = pos;

	    } else { 
	    	// Evict this frame as it is never used again
	    	return i;
	    }
	}
	// Find the longest distance to the next occurance
    int longest = -1;
    unsigned int frame = 0;
    for (i = 0; i < memsize; i++) {
    	if (distances[i] > longest) {
    		longest = distances[i];
    		frame = i;
    	}
    }
    return frame;
}

/* This function is called on each access to a page to update any information
 * needed by the opt algorithm.
 * Input: The page table entry for the page that is being accessed.
 */
void opt_ref(pgtbl_entry_t *p) {
	trace_pos++;
	return;
}

/* Initializes any data structures needed for this
 * replacement algorithm.
 */
void opt_init() {

	// Open tracefile
	FILE *tracefile_ptr = fopen(tracefile, "r");
	if (!tracefile_ptr) {
		perror("Cannot open tracefile\n");
	}

	// Find number of references in tracefile
	num_of_traces = 0;
	char buf[MAX_BUF_SIZE];
	while (fgets(buf, MAX_BUF_SIZE, tracefile_ptr)) {
		if(buf[0] != '=') {
			num_of_traces++;
		}
	}

	// Initialize traces
	traces = malloc(sizeof(addr_t) * num_of_traces);

	int i = 0; // for index in traces
	char type;
	addr_t vaddr;
	fseek(tracefile_ptr, 0, SEEK_SET);
    while (fgets(buf, MAX_BUF_SIZE, tracefile_ptr) != NULL) {
        if (buf[0] != '=') {
            sscanf(buf, "%c %lx", &type, &vaddr);
            traces[i] = vaddr;
            i++;
        } 
    }

	// Close tracefile
	int close = fclose(tracefile_ptr);
	if (close != 0) {
		perror("Cannot close tracefile\n");
	}

	// Initialize position of trace to 0
	trace_pos = 0;
	// Initialize the list of distances for each frame to their next occurances
	distances = malloc(sizeof(int) * memsize);
}

